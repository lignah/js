const fs = require('fs');
const regedit_rce = fs.readFileSync('./memo_regedit.exe');  // 바이너리 파일

exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/octet-stream' },
    body: regedit_rce.toString('base64'),
    isBase64Encoded: true
  };
};

console.log(regedit_rce.length)